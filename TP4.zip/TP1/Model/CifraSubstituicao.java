package Model;

import java.io.IOException;
import java.io.RandomAccessFile;

public class CifraSubstituicao {

    // Função para criptografar o arquivo
    public void encryptFile(String inputFile, String outputFile) {
        try (RandomAccessFile input = new RandomAccessFile(inputFile, "r");
             RandomAccessFile output = new RandomAccessFile(outputFile, "rw")) {

            long length = input.length();
            for (long i = 0; i < length; i++) {
                input.seek(i);
                byte originalByte = input.readByte();

                // Substituição simples: Adiciona 1 ao valor do byte
                byte encryptedByte = (byte) (originalByte + 1);

                output.writeByte(encryptedByte);
            }

            System.out.println("Arquivo criptografado com sucesso!");
        } catch (IOException e) {
            System.err.println("Erro ao criptografar o arquivo: " + e.getMessage());
        }
    }

    // Função para descriptografar o arquivo
    public void decryptFile(String inputFile, String outputFile) {
        try (RandomAccessFile input = new RandomAccessFile(inputFile, "r");
             RandomAccessFile output = new RandomAccessFile(outputFile, "rw")) {

            long length = input.length();
            for (long i = 0; i < length; i++) {
                input.seek(i);
                byte encryptedByte = input.readByte();

                // Substituição inversa: Subtrai 1 do valor do byte
                byte originalByte = (byte) (encryptedByte - 1);

                output.writeByte(originalByte);
            }

        } catch (IOException e) {
            System.err.println("Erro ao descriptografar o arquivo: " + e.getMessage());
        }
    }

    public void main(String[] args) {
        // Arquivos de exemplo
        String inputFile = "Files\\data.bin";
        String encryptedFile = "encrypted.bin";
        String decryptedFile = "decrypted.bin";

        // Criptografar e descriptografar o arquivo
        encryptFile(inputFile, encryptedFile);
        decryptFile(encryptedFile, decryptedFile);
    }
}
