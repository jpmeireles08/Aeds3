package Model;

import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import javax.crypto.Cipher;
import java.util.Arrays;
import java.io.RandomAccessFile;

public class CifraRSA {

    public static final int KEY_SIZE = 2048;

    public static void main(String[] args) {
        try {
            // Gera par de chaves RSA
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(KEY_SIZE);
            KeyPair keyPair = keyGen.generateKeyPair();

            // Arquivos binários
            String inputFile = "Files\\data.bin";
            String encryptedFile = "encrypted.dat";
            String decryptedFile = "decrypted.dat";

            // Executa a criptografia e descriptografia
            encryptFileRSA(inputFile, encryptedFile, keyPair.getPublic());
            decryptFileRSA(encryptedFile, decryptedFile, keyPair.getPrivate());

            System.out.println("Processo concluído com sucesso.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void encryptFileRSA(String inputPath, String outputPath, PublicKey publicKey) throws Exception {
        RandomAccessFile inputFile = new RandomAccessFile(inputPath, "r");
        RandomAccessFile outputFile = new RandomAccessFile(outputPath, "rw");

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);

        byte[] buffer = new byte[KEY_SIZE / 8 - 11]; // Tamanho máximo permitido pelo RSA para um bloco
        byte[] encrypted;

        while (inputFile.getFilePointer() < inputFile.length()) {
            int bytesRead = inputFile.read(buffer);
            encrypted = cipher.doFinal(Arrays.copyOf(buffer, bytesRead));
            outputFile.writeInt(encrypted.length); // Guarda o tamanho do bloco
            outputFile.write(encrypted);
        }

        inputFile.close();
        outputFile.close();
        System.out.println("Arquivo criptografado: " + outputPath);
    }

    public static void decryptFileRSA(String inputPath, String outputPath, PrivateKey privateKey) throws Exception {
        RandomAccessFile inputFile = new RandomAccessFile(inputPath, "r");
        RandomAccessFile outputFile = new RandomAccessFile(outputPath, "rw");

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);

        while (inputFile.getFilePointer() < inputFile.length()) {
            int blockSize = inputFile.readInt(); // Lê o tamanho do bloco
            byte[] encryptedBlock = new byte[blockSize];
            inputFile.readFully(encryptedBlock);

            byte[] decrypted = cipher.doFinal(encryptedBlock);
            outputFile.write(decrypted);
        }

        inputFile.close();
        outputFile.close();
        System.out.println("Arquivo descriptografado: " + outputPath);
    }
}
